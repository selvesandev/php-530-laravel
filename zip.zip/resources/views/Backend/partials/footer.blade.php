
<!-- footer content -->
<footer>
	<div class="pull-right">
		Php 5 PM - Bootstrap Admin Template by <a href="">It training nepal.</a> &copy;
	</div>
	<div class="clearfix"></div>
</footer>
<!-- /footer content -->
