@extends('Frontend.master')

@section('content')
	<div class="flex-center position-ref full-height">
		<div class="content">
			<h1>About</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam cupiditate explicabo illo illum, in
				molestias mollitia, nisi nulla quam quis rerum, tempora temporibus totam. Cupiditate laboriosam laborum
				natus nemo temporibus?</p>
		</div>
	</div>
@endsection
