<?php $__env->startSection('title'); ?>
	News
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="right_col" role="main">

		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="x_panel">
					<div class="x_title">
						<h2>News</h2>

						<div class="clearfix"></div>
					</div>
					<div class="x_content">
						<?php echo $__env->make('Backend.message.sucfail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

						<table class="table table-striped">
							<thead>
							<tr>
								<th>#</th>
								<th>Title</th>
								<th>Image</th>
								<th>Categories</th>
								<th>Summary</th>
								<th>Priority</th>
								<th>Action</th>
							</tr>
							</thead>
							<tbody>


							<?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td><?php echo e($loop->iteration); ?></td>
									<td><?php echo e($value->title); ?> <br>
										<small><?php echo e($value->slug); ?></small>
										|
										<small><?php echo e(!empty($value->created_at) ? $value->created_at->diffForHumans() : '-'); ?></small>
										<br>
										<small><?php echo e($value->admin->name); ?></small>
									</td>
									<td><img src="<?php echo e(URL::to('img/news/'.$value->image)); ?>" height="50" alt=""></td>
									<td>
										<?php $__currentLoopData = $value->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<span class="label label-default"><?php echo e($category->name); ?></span> &nbsp;
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</td>
									<td>
										<?php echo e(str_limit($value->summary,15)); ?>

									</td>
									<td>
										<form method="post" action="<?php echo e(route('update-priority')); ?>">
											<input type="hidden" name="id" value="<?php echo e($value->id); ?>">
											<?php echo csrf_field(); ?>
											<?php if($value->priority==1): ?>
												<button type="button" class="btn btn-success"><i
															class="fa fa-check"></i>

												</button>
											<?php else: ?>
												<button class="btn btn-default"><i class="fa fa-times"></i></button>
											<?php endif; ?>
										</form>
									</td>
									<td></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<tr>
									<td colspan="6">
										<div class="alert alert-danger">
											No news available.
										</div>
									</td>
								</tr>
							<?php endif; ?>

							</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>

	</div>
	<!-- /page content -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>