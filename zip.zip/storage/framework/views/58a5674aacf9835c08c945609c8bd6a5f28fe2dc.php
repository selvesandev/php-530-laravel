<?php if($errors->has($field)): ?>
	<p class="error"><?php echo e($errors->first($field)); ?></p>
<?php endif; ?>