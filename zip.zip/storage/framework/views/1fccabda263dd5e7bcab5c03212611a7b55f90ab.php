<?php $__env->startSection('title'); ?>
	Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="right_col" role="main">

		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="x_panel">
					<div class="x_title">
						<h2>Admins</h2>

						<div class="clearfix"></div>
					</div>
					<div class="x_content">
						<?php echo $__env->make('Backend.message.sucfail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

						<table class="table table-striped">
							<thead>
							<tr>
								<th>#</th>
								<th>Name</th>
								<th>Email</th>
								<th>Image</th>
								<th>Status</th>
								<th width="4%">Privilege</th>
								<th>Action</th>
							</tr>
							</thead>
							<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<th scope="row"><?php echo e($loop->iteration); ?></th>
									<td width="15%"><?php echo e($admin->name); ?></td>
									<td><?php echo e($admin->email); ?></td>
									<td>
										<img src="<?php echo e(URL::to('/img/admin/'.$admin->image)); ?>" height="40" alt="">
									</td>

									<td>
										<form method="post" action="<?php echo e(route('update-status')); ?>">
											<?php echo e(csrf_field()); ?>

											<input type="hidden" name="id" value="<?php echo e($admin->id); ?>">
											<?php if(!$admin->status): ?>
												<button name="btnstatus" value="enable" type="submit"
														class="btn btn-success btn-sm"><i
															class="fa fa-check"></i>
												</button>
											<?php else: ?>
												<button name="btnstatus" value="disable" type="submit"
														class="btn btn-danger btn-sm"><i
															class="fa fa-check"></i>
												</button>
											<?php endif; ?>
										</form>
									</td>
									<td>
										<?php if($admin->privilege=='a'): ?>
											<i class="fa fa-user"></i>
										<?php else: ?>
											<i class="fa fa-user-secret"></i>
										<?php endif; ?>

									</td>
									<td>
										<a onclick="return confirm('Are you sure?')"
										   href="<?php echo e(route('delete-admin',['id'=>$admin->id])); ?>"
										   class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<tr>
									<td colspan="7">
										<div class="alert alert-danger">
											No admins available.
										</div>
									</td>
								</tr>
							<?php endif; ?>

							</tbody>
						</table>

						<?php echo e($admins->links()); ?>


					</div>
				</div>
			</div>
		</div>

	</div>
	<!-- /page content -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>