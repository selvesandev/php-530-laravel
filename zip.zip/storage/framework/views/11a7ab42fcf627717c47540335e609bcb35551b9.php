<!-- jQuery -->
<script src="<?php echo e(URL::to('lib/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL::to('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(URL::to('lib/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>"></script>
<script src="<?php echo e(URL::to('lib/select2/js/select2.js')); ?>"></script>
<script src="<?php echo e(URL::to('lib/daterange/moment.min.js')); ?>"></script>
<script src="<?php echo e(URL::to('lib/daterange/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(URL::to('lib/tagsinput/jquery.tagsinput.min.js')); ?>"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo e(URL::to('js/admin.js')); ?>"></script>
<script src="<?php echo e(URL::to('js/customa.js')); ?>"></script>
</body>
</html>

