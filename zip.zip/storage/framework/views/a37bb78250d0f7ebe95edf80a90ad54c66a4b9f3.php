<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- Meta, title, CSS, favicons, etc. -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="images/favicon.ico" type="image/ico"/>

	<title><?php echo $__env->yieldContent('title'); ?></title>

	<link rel="stylesheet" href="<?php echo e(URL::to('lib/bootstrap/css/bootstrap.min.css')); ?>">
	<!-- Font Awesome -->
	<link href="<?php echo e(URL::to('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet"/>

	<link rel="stylesheet"
		  href="<?php echo e(URL::to('lib/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.css')); ?>"/>
	<link rel="stylesheet" href="<?php echo e(URL::to('lib/select2/css/select2.css')); ?>"/>
	<link rel="stylesheet" href="<?php echo e(URL::to('/lib/daterange/daterangepicker.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(URL::to('/lib/tagsinput/jquery.tagsinput.min.css')); ?>">

	<!-- Custom Theme Style -->
	<link href="<?php echo e(URL::to('/css/admin.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::to('/css/customa.css')); ?>" rel="stylesheet">
	
	
	<?php echo $__env->yieldContent('headjs'); ?>

</head>

<body class="nav-md">