<?php echo $__env->make('Backend.partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container body">
	<div class="main_container">
		<?php echo $__env->make('Backend.partials.sidenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make('Backend.partials.top-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php echo $__env->yieldContent('content'); ?>

		<?php echo $__env->make('Backend.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</div>
</div>


<?php echo $__env->make('Backend.partials.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>