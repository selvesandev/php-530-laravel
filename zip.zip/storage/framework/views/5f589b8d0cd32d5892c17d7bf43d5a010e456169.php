<?php $__env->startSection('title'); ?>
	Add news
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="right_col" role="main">

		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="x_panel">
					<div class="x_title">
						<h2>Add News</h2>

						<div class="clearfix"></div>
					</div>
					<div class="x_content">

						<?php echo $__env->make('Backend.message.sucfail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

						<form enctype="multipart/form-data" action="<?php echo e(route('news-add')); ?>" method="post">
							<?php echo e(csrf_field()); ?>


							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="">Title</label>
										<input type="text" id="news-title" placeholder="News title" name="title"
											   class="form-control">
										<?php echo $__env->make('Backend.message.error',['field'=>'title'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									</div>
								</div>
								<div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="">Select Category</label>
											<select multiple id="categorySelector" name="category[]"
													class="form-control">
												<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>

											<?php echo $__env->make('Backend.message.error',['field'=>'category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										</div>
									</div>


									<div class="col-md-6">
										<div class="form-group">
											<label for="">Upload Image</label>
											<input type="file" name="cover_image" class="form-control">
										</div>

										<?php echo $__env->make('Backend.message.error',['field'=>'cover_image'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									</div>
								</div>

								<div class="col-md-6">
									<div class="form-group">
										<label for="">News Date</label>
										<input type="text" name="news_date" class="form-control">
									</div>

									<?php echo $__env->make('Backend.message.error',['field'=>'news_date'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</div>
								<div class="clearfix"></div>
								<hr>

								<div class="col-md-12">
									<div class="form-group">
										<label for="">Keywords</label>
										<input type="text" name="keywords" id="news_keywords" class="tags form-control">

										<?php echo $__env->make('Backend.message.error',['field'=>'keywords'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									</div>
								</div>

								<div class="clearfix"></div>
								<br>
								<br>
								<br>

								<div class="col-md-12">
									<textarea name="summary" class="form-control" rows="4"></textarea>

									<?php echo $__env->make('Backend.message.error',['field'=>'summary'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</div>


								<div class="clearfix"></div>
								<br>

								<br>
								<br>


								<div class="form-group">

									<div class="col-md-12">
										<textarea name="details" id="details" rows="20"></textarea>

										<?php echo $__env->make('Backend.message.error',['field'=>'details'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									</div>
								</div>

								<div class="clearfix">

								</div>
								<br>

								<div class="form-group">

									<div class="col-md-12">
										<button type="submit" class="btn btn-success btn-lg btn-block">Create News
										</button>
									</div>
								</div>
								<br>
								<br>

							</div>
						</form>

					</div>
				</div>
			</div>
		</div>

	</div>
	<!-- /page content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('headjs'); ?>

	<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
	<script>tinymce.init({selector: '#details'});</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>