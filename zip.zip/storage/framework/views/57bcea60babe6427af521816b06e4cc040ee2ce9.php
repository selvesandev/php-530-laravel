<?php $__env->startSection('content'); ?>

	<div class="flex-center position-ref full-height">
		<div class="content">
			<h1>Home</h1>
			<h5>Welcome!!</h5>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam cupiditate explicabo illo illum, in
				molestias mollitia, nisi nulla quam quis rerum, tempora temporibus totam. Cupiditate laboriosam laborum
				natus nemo temporibus?</p>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>