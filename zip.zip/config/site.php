<?php

return [
	'admin-dashboard' => '@admin@'
];